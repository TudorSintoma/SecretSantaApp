package main;


import controller.LoginController;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        LoginController loginController = new LoginController();
    }
}

//parolaTudor