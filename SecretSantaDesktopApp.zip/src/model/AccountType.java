package model;

public enum AccountType {
    ORGANIZER,
    PARTICIPANT
}
